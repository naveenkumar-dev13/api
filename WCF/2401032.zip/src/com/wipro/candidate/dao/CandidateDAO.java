package com.wipro.candidate.dao;

import com.wipro.candidate.bean.CandidateBean;
import com.wipro.candidate.util.DBUtil;

import java.sql.*;
import java.util.ArrayList;

public class CandidateDAO {
    public String addCandidate(CandidateBean candidateBean) {
        String query = "INSERT INTO CANDIDATE_TBL VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBUtil.getDBConn();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, candidateBean.getId());
            pstmt.setString(2, candidateBean.getName());
            pstmt.setInt(3, candidateBean.getM1());
            pstmt.setInt(4, candidateBean.getM2());
            pstmt.setInt(5, candidateBean.getM3());
            pstmt.setString(6, candidateBean.getResult());
            pstmt.setString(7, candidateBean.getGrade());

            int rows = pstmt.executeUpdate();
            if (rows > 0) {
                return "SUCCESS";
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return "FAIL";
    }

    public ArrayList<CandidateBean> getByResult(String criteria) {
        ArrayList<CandidateBean> candidates = new ArrayList<>();
        String query = "SELECT * FROM CANDIDATE_TBL";
        if (criteria.equalsIgnoreCase("PASS")) {
            query += " WHERE Result = 'PASS'";
        } else if (criteria.equalsIgnoreCase("FAIL")) {
            query += " WHERE Result = 'FAIL'";
        }

        try (Connection conn = DBUtil.getDBConn();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                CandidateBean candidate = new CandidateBean();
                candidate.setId(rs.getString("ID"));
                candidate.setName(rs.getString("Name"));
                candidate.setM1(rs.getInt("M1"));
                candidate.setM2(rs.getInt("M2"));
                candidate.setM3(rs.getInt("M3"));
                candidate.setResult(rs.getString("Result"));
                candidate.setGrade(rs.getString("Grade"));
                candidates.add(candidate);
            }

            if (candidates.isEmpty()) {
                return null;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return candidates;
    }

    public String generateCandidateId(String name) {
        String candidateId = null;
        String query = "SELECT CANDID_SEQ.NEXTVAL FROM DUAL";

        try (Connection conn = DBUtil.getDBConn();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            if (rs.next()) {
                int seqValue = rs.getInt(1);
                candidateId = name.substring(0, 2).toUpperCase() + seqValue;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return candidateId;
    }
}
