package com.wipro.candidate.service;

import com.wipro.candidate.bean.CandidateBean;
import com.wipro.candidate.dao.CandidateDAO;
import com.wipro.candidate.util.WrongDataException;

import java.util.ArrayList;
import java.util.Scanner;

public class CandidateMain {
    public static void main(String[] args) {
        CandidateMain candidateMain = new CandidateMain();
        Scanner scanner = new Scanner(System.in);
        System.out.println("1. Add Candidate");
        System.out.println("2. Display Candidates");
        System.out.print("Enter choice: ");
        int choice = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        if (choice == 1) {
            CandidateBean candidateBean = new CandidateBean();
            System.out.print("Enter name: ");
            candidateBean.setName(scanner.nextLine());
            System.out.print("Enter marks in subject 1: ");
            candidateBean.setM1(scanner.nextInt());
            System.out.print("Enter marks in subject 2: ");
            candidateBean.setM2(scanner.nextInt());
            System.out.print("Enter marks in subject 3: ");
            candidateBean.setM3(scanner.nextInt());
            String result = candidateMain.addCandidate(candidateBean);
            System.out.println(result);
        } else if (choice == 2) {
            System.out.print("Enter criteria (PASS/FAIL/ALL): ");
            String criteria = scanner.nextLine();
            ArrayList<CandidateBean> candidates = candidateMain.displayAll(criteria);
            if (candidates != null) {
                for (CandidateBean candidate : candidates) {
                    System.out.println(candidate.getId() + " - " + candidate.getName() + " - " +
                            candidate.getM1() + " - " + candidate.getM2() + " - " + candidate.getM3() +
                            " - " + candidate.getResult() + " - " + candidate.getGrade());
                }
            } else {
                System.out.println("No records found");
            }
        }
    }

    public String addCandidate(CandidateBean candBean) {
        if (candBean == null || candBean.getName().isEmpty() || candBean.getName().length() < 2 ||
                candBean.getM1() < 0 || candBean.getM1() > 100 ||
                candBean.getM2() < 0 || candBean.getM2() > 100 ||
                candBean.getM3() < 0 || candBean.getM3() > 100) {
            return "Data incorrect";
        }

        CandidateDAO candidateDAO = new CandidateDAO();
        String candidateId = candidateDAO.generateCandidateId(candBean.getName());
        candBean.setId(candidateId);

        int totalMarks = candBean.getM1() + candBean.getM2() + candBean.getM3();
        if (totalMarks >= 240) {
            candBean.setResult("PASS");
            candBean.setGrade("Distinction");
        } else if (totalMarks >= 180) {
            candBean.setResult("PASS");
            candBean.setGrade("First Class");
        } else if (totalMarks >= 150) {
            candBean.setResult("PASS");
            candBean.setGrade("Second Class");
        } else if (totalMarks >= 105) {
            candBean.setResult("PASS");
            candBean.setGrade("Third Class");
        } else {
            candBean.setResult("FAIL");
            candBean.setGrade("No Grade");
        }

        String result = candidateDAO.addCandidate(candBean);
        if ("SUCCESS".equals(result)) {
            return candidateId + ":" + candBean.getResult();
        } else {
            return "Error";
        }
    }

    public ArrayList<CandidateBean> displayAll(String criteria) {
        if (!criteria.equalsIgnoreCase("PASS") &&
            !criteria.equalsIgnoreCase("FAIL") &&
            !criteria.equalsIgnoreCase("ALL")) {
            try {
                throw new WrongDataException();
            } catch (WrongDataException e) {
                e.printStackTrace();
                return null;
            }
        }

        CandidateDAO candidateDAO = new CandidateDAO();
        return candidateDAO.getByResult(criteria);
    }
}
